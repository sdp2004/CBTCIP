/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.guessthenumber;

/**
 *
 * @author Soumi Pal
 */
import java.util.*;
public class Guessthenumber{ 

    public static void guess(){
// Java program for the above approach
        		Scanner sc = new Scanner(System.in);

		// Generate the numbers
		int number = 1 + (int)(100* Math.random());
                int point=0;
		// Given N trials
		int N = 5;

		int i, guess;

		System.out.println(
			"A number is chosen between 1 to 100."
			+ "Guess the number"
			+ " within 5 trials."
                         + "Get points at each step");

		// Iterate over K Trials
		for (i = 0; i < N; i++) {

			System.out.println(
				"Guess the number:");

			// Take input for guessing
			guess = sc.nextInt();

			// If the number is guessed
			if (number == guess) {
				System.out.println(
					"Congratulations!"
					+ " You guessed the number.");
                                point+=5;
                                System.out.println("Total point earned is"+point);
                                
				break;
			}
			else if (number > guess
					&& i != N - 1) {
				System.out.println(
					"The number is "
					+ "greater than " + guess);
                                if (number==(guess+1))
                                {
                                    point+=2;
                                    System.out.println("Total point earned is"+point);
                                }
                                else if (number==(guess+2))
                                {
                                    point+=1;
                                    System.out.println("Total point earned is"+point);
                                }
                                else
                                {
                                    System.out.println("Point not earned");
                                }
			}
			else if (number < guess
					&& i != N - 1) {
				System.out.println(
					"The number is"
					+ " less than " + guess);
                                if (number==(guess-1))
                                {
                                    point+=2;
                                    System.out.println("Total point earned is"+point);
                                    
                                }
                                else if (number==(guess-2))
                                {
                                    point+=1;
                                    System.out.println("Total point earned is"+point);
                                    
                                }
                                else
                                {
                                    System.out.println("Point not earned");
                                }
			}
		}

		if (i == N) {
			System.out.println(
				"You have exhausted"
				+ " K trials.");

			System.out.println(
				"The number was " + number);
		}
	}




	// Driver Code
	public static void main(String arg[])
	{

		// Function Call
		guess();
	}


    }

